class Dancer
	attr_reader :name
	attr_accessor :age


	def initialize(name, age)
		@name = name
		@age = age
	end

	def pirouette
		"*twirls*"
	end

	def bow
		"*bows*"
	end

	def card
		card = []
	end

	def queue_dance_with(partner)
		card << partner
	end

	def routine
		"The dancer has their moves perfectly memorized."
	end 
end